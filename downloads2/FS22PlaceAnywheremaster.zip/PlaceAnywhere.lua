-- PlaceAnywhere mod

PlaceAnywhere = {}; 


function PlaceAnywhere:deleteMap()
end; 

function PlaceAnywhere:mouseEvent(posX, posY, isDown, isUp, button) 
end; 

function PlaceAnywhere:keyEvent(unicode, sym, modifier, isDown) 
end; 

function PlaceAnywhere:update(dt) 
end; 

function PlaceAnywhere:draw(PlaceAnywhere)
end; 

function PlaceAnywhere:setBlockedAreaMap(superFunc, ...)
    return true;
end

function PlaceAnywhere:hasObjectOverlap(superFunc, ...)   
    return false;
end

function PlaceAnywhere:isInsidePlacementPlaces(superFunc, ...)   
    return false;
end

function PlaceAnywhere:isInsideRestrictedZone(superFunc, ...)   
    return false;
end

function PlaceAnywhere:hasOverlapWithPoint(superFunc, ...)   
    return false;
end

function PlaceAnywhere:setOutsideAreaConstraints(superFunc, ...)   
    return superFunc(self, 0, 0, 0);
end

function PlaceAnywhere:setDynamicObjectCollisionMask(superFunc, ...)   
    return superFunc(self, 0);
end

function PlaceAnywhere:onTerrainValidationFinished(superFunc, p1, p2, p3)      
    return superFunc(self, 0, p2, p3);
end

addModEventListener(PlaceAnywhere);