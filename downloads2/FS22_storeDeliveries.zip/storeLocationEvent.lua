﻿----------------------------------------------------------------------------
----Author: ViperGTS96------------------------------------------------------
----------------------------------------------------------------------------
--------------------"The simplest design is the best design." --------------
----------------------------------------------------------------------------
storeLocationEvent = {};
storeLocationEvent_mt = Class(storeLocationEvent, Event);
InitEventClass(storeLocationEvent,"storeLocationEvent");

function storeLocationEvent:emptyNew()
    local self = Event.new(storeLocationEvent_mt);
    self.className = "storeLocationEvent";
    return self;
end;
function storeLocationEvent:new(startX, startY, startZ, rotX, rotY, rotZ, dirX, dirY, dirZ, dirPerpX, dirPerpY, dirPerpZ, tX,tY,tZ)
    local self = storeLocationEvent.emptyNew();
    --self.base = base;
    self.startX = startX;
    self.startY = startY;
    self.startZ = startZ;
    self.rotX = rotX;
    self.rotY = rotY;
    self.rotZ =	rotZ;
    self.dirX = dirX;
    self.dirY = dirY;
    self.dirZ = dirZ;
    self.dirPerpX = dirPerpX;
    self.dirPerpY = dirPerpY;
    self.dirPerpZ = dirPerpZ;
    self.tX = tX;
    self.tY = tY;
    self.tZ = tZ;
    return self;
end;
function storeLocationEvent:readStream(streamId,connection)
    --self.base = NetworkUtil.readNodeObject(streamId);
    self.startX = streamReadFloat32(streamId);
    self.startY = streamReadFloat32(streamId);
    self.startZ = streamReadFloat32(streamId);
	self.rotX = streamReadFloat32(streamId);
    self.rotY = streamReadFloat32(streamId);
    self.rotZ = streamReadFloat32(streamId);
    self.dirX = streamReadFloat32(streamId);
    self.dirY = streamReadFloat32(streamId);
    self.dirZ = streamReadFloat32(streamId);
    self.dirPerpX = streamReadFloat32(streamId);
    self.dirPerpY = streamReadFloat32(streamId);
    self.dirPerpZ = streamReadFloat32(streamId);
    self.tX = streamReadFloat32(streamId);
    self.tY = streamReadFloat32(streamId);
    self.tZ = streamReadFloat32(streamId);
    self:run(connection);
end;
function storeLocationEvent:writeStream(streamId,connection)
    --NetworkUtil.writeNodeObject(streamId,self.base);
    streamWriteFloat32(streamId,self.startX);
    streamWriteFloat32(streamId,self.startY);
    streamWriteFloat32(streamId,self.startZ);
    streamWriteFloat32(streamId,self.rotX);
    streamWriteFloat32(streamId,self.rotY);
    streamWriteFloat32(streamId,self.rotZ);
    streamWriteFloat32(streamId,self.dirX);
    streamWriteFloat32(streamId,self.dirY);
    streamWriteFloat32(streamId,self.dirZ);
    streamWriteFloat32(streamId,self.dirPerpX);
    streamWriteFloat32(streamId,self.dirPerpY);
    streamWriteFloat32(streamId,self.dirPerpZ);
    streamWriteFloat32(streamId,self.tX);
    streamWriteFloat32(streamId,self.tY);
    streamWriteFloat32(streamId,self.tZ);
end;
function storeLocationEvent:run(connection)
    g_currentMission.storeDeliveriesSrcRef:updateStoreLocationEvent(self.startX,self.startY,self.startZ,self.rotX,self.rotY,self.rotZ,self.dirX,self.dirY,self.dirZ,self.dirPerpX,self.dirPerpY,self.dirPerpZ, self.tX,self.tY,self.tZ, true);
    if not connection:getIsServer() then
        g_server:broadcastEvent(storeLocationEvent:new(self.startX,self.startY,self.startZ,self.rotX,self.rotY,self.rotZ,self.dirX,self.dirY,self.dirZ,self.dirPerpX,self.dirPerpY,self.dirPerpZ,self.tX,self.tY,self.tZ),nil,connection);
    end;
end;
function storeLocationEvent.sendEvent(startX,startY,startZ,rotX,rotY,rotZ,dirX,dirY,dirZ,dirPerpX,dirPerpY,dirPerpZ,tX,tY,tZ,noEventSend)
    if noEventSend == nil or noEventSend == false then
        if g_server ~= nil then
            g_server:broadcastEvent(storeLocationEvent:new(startX,startY,startZ,rotX,rotY,rotZ,dirX,dirY,dirZ,dirPerpX,dirPerpY,dirPerpZ,tX,tY,tZ));
        else
            g_client:getServerConnection():sendEvent(storeLocationEvent:new(startX,startY,startZ,rotX,rotY,rotZ,dirX,dirY,dirZ,dirPerpX,dirPerpY,dirPerpZ,tX,tY,tZ));
        end;
    end;
end;