﻿----------------------------------------------------------------------------
----Author: ViperGTS96------------------------------------------------------
----------------------------------------------------------------------------
--------------------"The simplest design is the best design." --------------
----------------------------------------------------------------------------
storePurchaseEvent = {};
storePurchaseEvent_mt = Class(storePurchaseEvent, Event);
InitEventClass(storePurchaseEvent,"storePurchaseEvent");

function storePurchaseEvent:emptyNew()
    local self = Event.new(storePurchaseEvent_mt);
    self.className = "storePurchaseEvent";
    return self;
end;
function storePurchaseEvent:new(charge, totalCharges, farmId)
    local self = storePurchaseEvent.emptyNew();
    self.charge = charge;
    self.totalCharges = totalCharges;
    self.farmId = farmId;
    return self;
end;
function storePurchaseEvent:readStream(streamId,connection)
    self.charge = streamReadFloat32(streamId);
    self.totalCharges = streamReadFloat32(streamId);
    self.farmId = streamReadInt8(streamId);
    self:run(connection);
end;
function storePurchaseEvent:writeStream(streamId,connection)
    streamWriteFloat32(streamId,self.charge);
    streamWriteFloat32(streamId,self.totalCharges);
    streamWriteInt8(streamId,self.farmId);
end;
function storePurchaseEvent:run(connection)
    g_currentMission.storeDeliveriesSrcRef:updateStorePurchaseEvent(self.charge,self.totalCharges, self.farmId, true);
    if not connection:getIsServer() then
        g_server:broadcastEvent(storePurchaseEvent:new(self.charge,self.totalCharges,self.farmId),nil,connection);
    end;
end;
function storePurchaseEvent.sendEvent(charge, totalCharges, farmId, noEventSend)
    if noEventSend == nil or noEventSend == false then
        if g_server ~= nil then
            g_server:broadcastEvent(storePurchaseEvent:new(charge, totalCharges, farmId));
        else
            g_client:getServerConnection():sendEvent(storePurchaseEvent:new(charge, totalCharges, farmId));
        end;
    end;
end;